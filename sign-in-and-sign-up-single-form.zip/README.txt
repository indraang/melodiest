A Pen created at CodePen.io. You can find this one at https://codepen.io/THEORLAN2/pen/mPLPwj.

 A single form to sign and to register. - Click on the tab Sign Up and Sign In to view the Effect